# GENERATED FILE #
from enum import Enum

from applitools.common.utils.general_utils import DeprecatedEnumVariant

__all__ = ("IosMultiDeviceTarget",)


class IosMultiDeviceTarget(Enum):
    def __call__(self):
        from ._device_target import IosDeviceTarget

        return IosDeviceTarget(self.value)

    iPhone_SE_3 = "iPhone SE (3rd generation)"
    iPhone_SE_2 = "iPhone SE (2nd generation)"
    iPhone_8 = "iPhone 8"
    iPhone_8_Plus = "iPhone 8 Plus"
    iPhone_13_mini = "iPhone 13 mini"
    iPhone_12_mini = "iPhone 12 mini"
    iPhone_11_Pro = "iPhone 11 Pro"
    iPhone_X = "iPhone X"
    iPhone_XR = "iPhone XR"
    iPhone_Xs = "iPhone Xs"
    iPhone_Xs_Max = "iPhone Xs Max"
    iPhone_11 = "iPhone 11"
    iPhone_11_Pro_Max = "iPhone 11 Pro Max"
    iPhone_12 = "iPhone 12"
    iPhone_12_Pro = "iPhone 12 Pro"
    iPhone_12_Pro_Max = "iPhone 12 Pro Max"
    iPhone_13 = "iPhone 13"
    iPhone_13_Pro = "iPhone 13 Pro"
    iPhone_13_Pro_Max = "iPhone 13 Pro Max"
    iPhone_14 = "iPhone 14"
    iPhone_14_Pro = "iPhone 14 Pro"
    iPhone_14_Plus = "iPhone 14 Plus"
    iPhone_14_Pro_Max = "iPhone 14 Pro Max"
